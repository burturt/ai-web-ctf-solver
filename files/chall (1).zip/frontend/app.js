const $ = document.querySelector.bind(document);

$('button').addEventListener('click', async () => {
  const query = $('textarea').value;
  const resp = await fetch('/search?q=' + encodeURIComponent(query))
    .then((r) => r.json());

  Swal.fire({
    title: 'Search',
    text: resp.entries
      ? 'Thats a cool CTF player'
      : 'That is not my favourite CTF player',
    icon: resp.entries ? 'success' : 'error',
  });
});
