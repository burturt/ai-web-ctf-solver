// this is the serverg
// it is amazing
//
// to run:
// npm ci
// node index.js
const express = require('express');
const path = require('path');
const fs = require('fs');

// ooooooo secret stuff to exfiltrate
const db = fs
  .readFileSync(path.join(__dirname, 'secret.txt'))
  .toString();

const app = express();

app.use('/', express.static(path.join(__dirname, 'frontend')));

app.get('/search', (req, res) => {
  // try going to the http://website/search?q=owooooo
  const query = req.query.q ?? '';
  res
    .status(200)
    .json({ entries: db.includes(query) });
});

app.listen(3000, () => console.log('Listening on http://0.0.0.0:3000'));
