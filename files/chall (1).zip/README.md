# My Favorite CTF Player

This is an application to find my favorite CTF player.

To run it locally, run below command in the terminal:

```sh
docker build -t favorite-ctf-player . && docker run -p 3000:3000 -it favorite-ctf-player
```

## CTF

Your goal in this challenge is to get the contents of `secret.txt` (which has the flag in it).

## Code Overview

frontend/ -
	contains the code for the website's frontend
	this is what your browser runs to allow you to interact with the main app
	for solving this challenge, you should probably not be using the frontend directly
	you _can_ yoink some code from the frontend in your solve script
	if you make your solve script in js
	(only do this if you know js, python with requests is plenty good enough for this chall)


index.js -
	this is the code of the server and is the code to focus on
	it has two simple functions:
		1) transport the frontend to your browser so you can interact with the server
		2) search for whether your string is a substring of `secret.txt`
	for this challenge, you want to look into how you can use `2)` to capture the flag
